<?php
session_start();
include 'conn.php';
$username= $_POST['username'];
$password= $_POST['password'];
$sql= "select * from admin where username='$username' and password= '$password'";
$res= mysqli_query($conn, $sql);
if(!mysqli_num_rows($res)==1){

	header("location:adminlogin.php");
}
else{
	header("location:admin_homepage.php");
}