<?php
session_start();
// $_SESSION['username'] = $_POST['username'];
if($_SERVER['REQUEST_METHOD']=="POST"){
	if (!preg_match("/^[A-Za-z]*+$/", $_POST['name'])) {
		echo "Please enter name";
	}

	else if(!preg_match("/^[A-Za-z]*+$/", $_POST['name'])){
		echo "Name must contain characters only";
	}

	 if(!preg_match("/^[A-Za-z]*+$/", $_POST['address'])){
		echo "Address must contain characters only";
	}
	if(!preg_match("/^[0-9]+$/", $_POST['contact'] )){
		echo "Contact is in invalid format";
	}
	if(!preg_match("/^[A-Za-z]*+$/", $_POST['uname'])){
		echo "Username must contain characters only";
	}
	else{
		include 'conn.php';
		$name= $_POST['name'];
		$add= $_POST['address'];
		$con= $_POST['contact'];
		$email= $_POST['email'];
		$un= $_POST['uname'];
		$pwd= $_POST['password'];


		$sql ="INSERT into user (name,address,contact,email,uname,password) 
				VALUES ('$name','$add','$con','$email','$un','$pwd')";

		$res=mysqli_query($conn,$sql);
		if(!$res){
			die('failed'. mysqli_error($conn));
		}
		else{
			
		header('location:login.php');
		}
	}	
	
}
?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
body {
  background-image: url('bglogin.jpg');
  background-size: 100%;
}
</style>
</head>
<title> Registration form</title>
<div class="header">
	<h2> <a href="form.php">Food ordering</a></h2>
	<h5 align="right"><a href= "form.php"> Back to home</a></h5>
</div>
<body>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" align= "center">

	<h1> <u>Register Now!</u></h1>	
	<label> Name: </label> <input type="text" name="name"><br> <br>
	<label>Address: </label> <input type="text" name="address"> <br> <br>
	<label>Contact no:</label> <input type="text" name="contact"> <br> <br>
<label>Email:</label> <input type="email" name="email"><br> <br>
	<label>Username:</label> <input type="text" name="uname"><br> <br>
	<label>Password:</label> <input type="password" name="password"><br> <br>
	<input type="submit" name="Register"> <br>
Already a user? <br><a href= "login.php" >Sign in now! </a>

</form>
 
<footer>
	<div class="footer">
<h6>Copyright © Akash Chauhan | Food ordering System</h6>
	</div>
</footer>
</body>
</html>
