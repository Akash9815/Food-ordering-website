<?php
session_start();
$_SESSION['username'] = $_POST['username'];
include "conn.php";
$name= $_POST['name'];
$address= $_POST['address'];
$contact= $_POST['contact'];
$email= $_POST['email'];
$uname= $_POST['uname'];
$password= $_POST['password'];
$sql= "insert into user(name, address, contact, email, uname, password)values 
('$name', '$address', '$contact', '$email', '$uname', '$password')";
$res= mysqli_query($conn, $sql);
if (!$res) {
	die("Insertion failed ". mysqli_connect_error($conn));
}
header("location:login.php");

?>
