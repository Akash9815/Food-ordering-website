<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
<form>
	<h1>Admin Home</h1>
	<div class="container">
	<div class = "view" ><a href="vieworder.php">View Order</a></div>
		<div class = "viewfeeds"><a href="viewfeeds.php">View feedbacks</a></div>
			<div class = "addmenu">	<a href="addmenu.php">Add New item </a></div>
			<div class = "menulist"><a href="menulist.php">Menu List</a></div>
			</div>
		<div class= "log"><a href="logout.php">Logout</a></div>
	
</form>
</body>
</html>