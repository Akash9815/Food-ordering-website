<?php

$server="localhost";
$user= 'root';
$password= '';
$db= 'cafe';
$conn= mysqli_connect($server, $user, $password, $db);

	$id = $_GET['id'];
	$sql = "Delete from product where id = " .$id;
	$res = mysqli_query($conn, $sql);
		if(!$res){
			die("failed to delete ".mysqli_error($conn));
		}
		else{
		header("location:vieworder.php");
		}
?>
<a href="admin_homepage">Go Home</a>