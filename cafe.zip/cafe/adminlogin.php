<!-- <!DOCTYPE html>
<html>
<head>
	<style>
body {
  background-image: url('bg.jpeg');
}
</style>
<link rel="stylesheet" type="text/css" href="style.css">
	<title>ADMIN LOGIN</title>
		<div class="header">
	
		<h4 align="right"><a href="form.php"> Back to home page </h4></a>	
			
		</div>
</head>
<body>
	
<form action="adminconn.php" method="POST" align="center">

<h1>	Admin Login: <br> </h1>
<h3>	Username:  <input type="text" name="username"><br> <br>
	Password: <input type="password" name="password"><br> <br>
	<input type="submit" value="submit"></h3>


</form>

</div>
</body>
<br><br> <br>
	<div class="footer">
Copyright © Aakash Chauhan | Illam Food Cafe
	</div>



</html> -->
<form action= "adminconnection.php" method= "post">
Username <input type= "text" name= "username"> <br> <br>
Password <input type="password" name= "password"> <br> <br>
<input type= "submit" value="submit">
</form>