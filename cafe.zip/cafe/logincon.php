<?php
session_start();
include 'conn.php';
$uname= $_POST['uname'];
$password= $_POST['password'];
$sql= "select *from user where uname='$uname' and password= '$password'";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res)==1){
	header("location:menu.php");
}
else{
	echo "Invalid credentials".header("location:login.php");
}
?>