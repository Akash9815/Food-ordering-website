<!DOCTYPE html>
<html>
<head>
<style>
body {
  background-image: url('bglogin.jpg');
  background-size: 100%;
}
</style>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

	<title>Login page</title>
</head>
<body>

<div class="header">
	<h2> <a href="form.php">Login to Order food</a></h2>
	<h5 align="right"><a href= "home.php"> Back to home</a></h5>
</div>

<br><br> <br><br>
<div class="login">
<form  method="POST" action="logincon.php">	
	<fieldset>
		<div class="userlogin">
<h2> User Login </h2>
</div>
		Username: <input type="text" name="uname"><br><br>
		Password: <input type="password" name="password"><br> <br>
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="submit" class="btn btn-success" value="submit">
		<br><br>
<h4 align="center">	Haven't signed it yet? <br>
		<a href=" register.php"> Create an account now! </a></h4>
	</fieldset>
</div>
</form>
<footer>
	<div class="footer">
<h6>Copyright © Ilam Food Cafe | Food ordering website</h6>
	</div>
</footer>
</body>
</html>
