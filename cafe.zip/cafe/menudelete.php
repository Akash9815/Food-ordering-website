<?php
$id = $_GET['id'];
include 'conn.php';
$sql = "Delete from product where id = " .$id;
$res = mysqli_query($conn, $sql);
if(!$res){
	die("failed to delete ".mysqli_error($conn));
}
else{
	header("location:menulist.php");

}

?>
