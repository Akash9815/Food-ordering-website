<?php
$server="localhost";
$user= 'root';
$password= '';
$db= 'cafe';
$conn= mysqli_connect($server, $user, $password, $db);

$name = $_POST['name'];
$image = $_POST['image'];
$price = $_POST['price'];

$sql = "insert into product(name, image, price) values('$name','$image','$price')";
$res = mysqli_query($conn, $sql);
if (!$res) {
	die("Failed to insert " .mysqli_error($conn));
}
else{
header("location: menulist.php");
}
?>
